Bonus
=====

Remember, *you must complete the full credit assignment to get any credit for the bonus assignment!*

The bonus adds operator>> overloads to the enum class and Coin class, and then focuses on writing a very simple menu-driven application for managing a numismatist's coin collection. This is important for the upcoming exam, so I *strongly* encourage you to attempt the bonus!


