Full Credit
===========

Your only task for the full credit portion of this assignment is to code the ```Coin``` class. You'll get to throw an exception and use a logger tool, though, as well as write the special members covered by the Rule of 3. *Enjoy!*