#include <string>
#include <iostream>

class Color
{
	//private instance variables
	private:
	int _red;
	int _green;
	int _blue;

	//public constructor and methods
	public:
	Color(int red, int green, int blue);
	std::string to_string();
	std::string colorize(std::string text);
};


//implementation of class Color

//constructor initializer list
Color::Color(int red, int green, int blue) : _red{red}, _green{green}, _blue{blue} {}

/*
method returns string representation of the RGB color
*/
std::string Color::to_string()
{
	//std::to_string(int n) turns n into a string and returns it; necessary for concatenation	
	return '(' + std::to_string(_red) + ',' + std::to_string(_green) + ',' + std::to_string(_blue) + ')';
}

/*
method returns parameter preceded by ANSI escape code for "set foreground color" to the _red, _green, _blue, and ends with ANSI escape code for "reset"
*/
std::string Color::colorize(std::string text)
{
	return "\033[38;2;" + std::to_string(_red) + ";" + std::to_string(_green) + ";" + std::to_string(_blue) + "m" + text + "\033[0m";
}

int main()
{
	//instantiate 3 Color objects
	Color red{255, 0, 0};
	Color pink{255, 167, 167};
	Color lime{211, 255, 167};

	//prints the three colors in their representative color
	std::cout << red.colorize("Red") + " " + pink.colorize("Blush Pink") + " " + lime.colorize("Lime Green") << std::endl;

	//asks user for 3 integers representing red, green, and blue
	int r, g, b;

	std::cout << "Enter the RGB values separated by a space: ";
	std::cin >> r;
	std::cin >> g;
	std::cin >> b;
	
	//instantiate user-entered RGB color
	Color color{r, g, b};

	//prints the user-entered color's string representation in its representative color
	std::cout << color.colorize(color.to_string()) << std::endl;

	return 0;
}
