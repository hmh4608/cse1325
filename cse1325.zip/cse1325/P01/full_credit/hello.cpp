#include <iostream>

int main()
{
	//output to console << "message" << new line character and clear stream	
	std::cout << "Hello, Hoang!" << std::endl;
	return 0;
}
